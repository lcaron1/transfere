<?php if (!defined('BASEPATH')) exit('no direct script access allowed');

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of ToDo
 *
 * @author adminSio
 */

/* @property CI_DB_active_record $db
 * 
 */
class ToDo extends CI_Controller{
    public function  index(){
        $all_todos = $this->TodoModel->get_all();
        $data = array();
        $data['title'] = "auboulot !";
        $data['todos'] = $all_todos;
        $data['count'] = $this->TodoModel->count();
        $data['countBool'] = $this->TodoModel->countBool(0);
        $this->load->view('TodoIndex',$data);
        
    }    
    public function __construct() {
        parent::__construct();
        $this->load->helper('url','form');
        $this->load->library('form_validation');  
        $this->load->model('TodoModel');
    }
    public function completed($id){
    $param = array('completed'=>1);
    $this->TodoModel->update($id,$param);
    redirect('ToDo/index');   
    }
    public function delete($id){
    $this->TodoModel->delete($id);
    redirect('ToDo/index');   
    }
    public function modifier($id){
    $this->form_validation->set_rules('ordre','ordre','required|numeric');
    $this->form_validation->set_rules('task','tache','required');
    $one_data = $this->TodoModel->get_By_Id($id);
    $data['id'] = $one_data['id'];
    $data['completed'] = $one_data['completed'];
    $data['ordre'] = $one_data['ordre'];
    $data['task'] = $one_data['task'];
        if($this->form_validation->run()==True){
            $ordre = $this->input->post('ordre');
            $task = $this->input->post('task');
            $param = array ('ordre'=>$ordre,'task'=>$task,'completed'=>0);
                $this->TodoModel->update($id, $param);
                redirect(base_url('ToDo/index'));
        }
        $this->load->view('TodoEdit', $data);
    
    }
    public function add(){
        $this->form_validation->set_rules('ordre','ordre','required|numeric');
        $this->form_validation->set_rules('task','tache','required');
        if($this->form_validation->run()==True){
            $ordre = $this->input->post('ordre');
            $task = $this->input->post('task');
            $param = array ('ordre'=>$ordre,'task'=>$task,'completed'=>0);
                $this->TodoModel->add($param);
                redirect(base_url('ToDo/index'));
           
            
        }
        $this->load->view('TodoAdd');
    }
    public function order(){
        $this->form_validation->set_rules("ordre[]","ordre",'required|numeric');
        $all_todos = $this->TodoModel->get_all();
        $data['todos'] = $all_todos;
        if($this->form_validation->run()==True){
            $ordre = $this->input->post('ordre[]');
            $i=0;
            
            foreach ($data['todos']as $todo)
            {
                $param = array('ordre'=>$ordre[$i]);
                $this->TodoModel->update($todo['id'],$param);
                $i = $i +1;
            }       
                redirect(base_url('ToDo/index'));
 
        }
        $this->load->view('TodoOrder', $data);
    }
    //put your code here
}
