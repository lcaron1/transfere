<?php if ( ! defined('BASEPATH')) exit ('no deirect script access allowed');


/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of TodoModel
 *
 * @author adminSio
 */
/* @property CI_DB_active_record $db
 * 
 */

class TodoModel extends CI_Model{
    function __construct(){
        parent::__construct();

    }
    function get_By_Id($id){
        return $this->db->get_where('Todo',array('id'=>$id))->row_array();
    }
    function get_all(){
        $this->db->order_by('ordre');
        return $this->db->get('Todo')->result_array();
    }
    function add($params){
        $this->db->insert('Todo',$params);
        return $this->db->insert_id();
    }
    function update ($id,$params){
        $this->db->where('id',$id);
        $this->db->update('Todo',$params);
    }
    function delete ($id){
        $this->db->delete('Todo',array('id'=>$id));
    }
    function count(){
        return $this->db->count_all('Todo');
    }
    function countBool($params){
        $this->db->where('completed',$params);
        return $this->db->count_all_results('Todo');
        
    }
    //put your code here
}
