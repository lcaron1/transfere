<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
echo validation_errors();
echo form_open('ToDo/add');
echo form_label('ordre : ','ordre');
echo form_input('ordre',set_value('ordre',0));
echo form_label('tache :','task');
echo form_input('task',set_value('task',''));
echo form_submit('Ajouter','Ajouter');
echo form_close();
