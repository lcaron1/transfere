<?php
echo validation_errors();
echo form_open('ToDo/modifier/'.$id);
echo form_label('id : ','id');
echo form_input('id',set_value('id',''));
echo form_label('ordre : ','ordre');
echo form_input('ordre',set_value('ordre',''));
echo form_label('tache :','task');
echo form_input('task',set_value('task',''));
echo form_label('completer : ','completed');
echo form_input('completed',set_value('completed',''));
echo form_submit('Update','Update');
echo form_close();
/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

