<!DOCTYPE html>
<html lang="fr">
    <head>
        <meta charset=""utf-8">
        <title><?php echo $title ?></title>
    </head>
    <body>
        <div class=""container">
             <h1>Liste de mes travaux</h1>
             <?php foreach ($todos as $todo):
                 ?> Ordre  :<?php echo $todo['ordre']; 
                 if($todo['completed']==true){
                     
                     ?>  Task : <?php echo '<s>'.$todo['task'].'</s>'; 
                 }
                 else{
                     ?>  Task : <?php echo $todo['task'];
                 }
                 ?>
                Id : <?php echo $todo['id']; ?>
                Completed : <?php echo $todo['completed']; ?>
                <a href=<?php echo base_url('/ToDo/completed/').$todo['id']?>>fait</a>
                <a href=<?php echo base_url('/ToDo/modifier/').$todo['id']?>>modifier</a>
                <a href=<?php echo base_url('/ToDo/delete/').$todo['id']?>>supprimer</a></br>
             <?php endforeach; ?></br>
             Toute les taches : <?php echo $count ?></br>
             Tache restante : <?php echo $countBool ?></br>
                <a href=<?php echo base_url('ToDo/add')?>>ajouter</a>
                <a href=<?php echo base_url('ToDo/order')?>>Réordonner les taches</a>
        </div><!--/.container -->
    </body>
</html>
  