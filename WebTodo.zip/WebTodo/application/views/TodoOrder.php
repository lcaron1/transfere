<h1>Réordonner mes taches</h1>
<?php
echo validation_errors();
echo form_open('ToDo/order');
$i = 10;
foreach ($todos as $todo):
    echo form_input('ordre[]',set_value('ordre',$i));
    echo form_label($todo['task'],'task').'</br>';
    $i = $i +10;
endforeach;

echo form_submit('Réordonner','Réordonner');
echo form_close();?>

